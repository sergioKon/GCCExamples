 typedef struct person{
    int id;
    char* name;
} Person;

Person *person;
